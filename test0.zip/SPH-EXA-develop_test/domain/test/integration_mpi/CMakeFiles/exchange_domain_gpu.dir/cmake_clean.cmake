file(REMOVE_RECURSE
  "CMakeFiles/exchange_domain_gpu.dir/exchange_domain_gpu.cpp.o"
  "CMakeFiles/exchange_domain_gpu.dir/exchange_domain_gpu.cpp.o.d"
  "CMakeFiles/exchange_domain_gpu.dir/test_main.cpp.o"
  "CMakeFiles/exchange_domain_gpu.dir/test_main.cpp.o.d"
  "exchange_domain_gpu"
  "exchange_domain_gpu.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/exchange_domain_gpu.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
