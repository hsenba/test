file(REMOVE_RECURSE
  "libcstone_gpu.a"
)
