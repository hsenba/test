# Empty dependencies file for neighbors_test_gpu.
# This may be replaced when dependencies are built.
