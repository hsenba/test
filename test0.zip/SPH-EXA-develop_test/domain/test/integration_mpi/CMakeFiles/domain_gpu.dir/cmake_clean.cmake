file(REMOVE_RECURSE
  "CMakeFiles/domain_gpu.dir/domain_gpu.cpp.o"
  "CMakeFiles/domain_gpu.dir/domain_gpu.cpp.o.d"
  "CMakeFiles/domain_gpu.dir/test_main.cpp.o"
  "CMakeFiles/domain_gpu.dir/test_main.cpp.o.d"
  "domain_gpu"
  "domain_gpu.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/domain_gpu.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
