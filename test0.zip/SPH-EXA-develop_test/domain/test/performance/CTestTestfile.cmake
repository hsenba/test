# CMake generated Testfile for 
# Source directory: /home/mhirota/work/SPH-EXA-develop/domain/test/performance
# Build directory: /home/mhirota/work/SPH-EXA-develop/domain/test/performance
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[scan_perf]=] "/usr/local/bin/mpiexec" "-n" "1" "/home/mhirota/work/SPH-EXA-develop/domain/test/performance/scan_perf")
set_tests_properties([=[scan_perf]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/mhirota/work/SPH-EXA-develop/domain/cmake/cstone_add_test.cmake;39;add_test;/home/mhirota/work/SPH-EXA-develop/domain/test/performance/CMakeLists.txt;8;cstone_add_test;/home/mhirota/work/SPH-EXA-develop/domain/test/performance/CMakeLists.txt;0;")
