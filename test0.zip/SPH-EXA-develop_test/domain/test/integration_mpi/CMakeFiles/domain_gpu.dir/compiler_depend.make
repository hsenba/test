# Empty compiler generated dependencies file for domain_gpu.
# This may be replaced when dependencies are built.
