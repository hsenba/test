# Install script for directory: /home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set default install directory permissions.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/globaloctree" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/globaloctree")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/globaloctree"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/globaloctree")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/globaloctree")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/globaloctree" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/globaloctree")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/globaloctree"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/globaloctree")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_halos" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_halos")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_halos"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/exchange_halos")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/exchange_halos")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_halos" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_halos")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_halos"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/exchange_halos")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/box_mpi" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/box_mpi")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/box_mpi"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/box_mpi")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/box_mpi")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/box_mpi" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/box_mpi")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/box_mpi"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/box_mpi")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_focus" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_focus")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_focus"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/exchange_focus")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/exchange_focus")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_focus" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_focus")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_focus"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/exchange_focus")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_keys" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_keys")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_keys"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/exchange_keys")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/exchange_keys")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_keys" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_keys")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_keys"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/exchange_keys")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/focus_transfer" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/focus_transfer")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/focus_transfer"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/focus_transfer")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/focus_transfer")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/focus_transfer" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/focus_transfer")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/focus_transfer"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/focus_transfer")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/domain_2ranks" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/domain_2ranks")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/domain_2ranks"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/domain_2ranks")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/domain_2ranks")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/domain_2ranks" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/domain_2ranks")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/domain_2ranks"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/domain_2ranks")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/domain_resize" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/domain_resize")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/domain_resize"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/domain_resize")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/domain_resize")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/domain_resize" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/domain_resize")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/domain_resize"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/domain_resize")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/treedomain" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/treedomain")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/treedomain"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/treedomain")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/treedomain")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/treedomain" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/treedomain")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/treedomain"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/treedomain")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_general" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_general")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_general"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/exchange_general")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/exchange_general")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_general" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_general")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_general"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/exchange_general")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_domain" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_domain")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_domain"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/exchange_domain")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/exchange_domain")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_domain" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_domain")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_domain"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/exchange_domain")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/focus_tree" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/focus_tree")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/focus_tree"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/focus_tree")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/focus_tree")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/focus_tree" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/focus_tree")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/focus_tree"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/focus_tree")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/domain_nranks" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/domain_nranks")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/domain_nranks"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/domain_nranks")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/domain_nranks")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/domain_nranks" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/domain_nranks")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/domain_nranks"
         OLD_RPATH "/usr/local/lib:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/domain_nranks")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_halos_gpu" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_halos_gpu")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_halos_gpu"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/exchange_halos_gpu")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/exchange_halos_gpu")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_halos_gpu" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_halos_gpu")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_halos_gpu"
         OLD_RPATH "/usr/local/lib:/usr/local/cuda-12.3/lib64:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/exchange_halos_gpu")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_domain_gpu" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_domain_gpu")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_domain_gpu"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/exchange_domain_gpu")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/exchange_domain_gpu")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/exchange_domain_gpu" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/exchange_domain_gpu")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/exchange_domain_gpu"
         OLD_RPATH "/usr/local/lib:/usr/local/cuda-12.3/lib64:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/exchange_domain_gpu")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/assignment_gpu" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/assignment_gpu")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/assignment_gpu"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/assignment_gpu")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/assignment_gpu")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/assignment_gpu" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/assignment_gpu")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/assignment_gpu"
         OLD_RPATH "/usr/local/lib:/usr/local/cuda-12.3/lib64:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/assignment_gpu")
    endif()
  endif()
endif()

if("x${CMAKE_INSTALL_COMPONENT}x" STREQUAL "xUnspecifiedx" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/domain_gpu" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/domain_gpu")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}/integration_mpi/domain_gpu"
         RPATH "")
  endif()
  list(APPEND CMAKE_ABSOLUTE_DESTINATION_FILES
   "/integration_mpi/domain_gpu")
  if(CMAKE_WARN_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(WARNING "ABSOLUTE path INSTALL DESTINATION : ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  if(CMAKE_ERROR_ON_ABSOLUTE_INSTALL_DESTINATION)
    message(FATAL_ERROR "ABSOLUTE path INSTALL DESTINATION forbidden (by caller): ${CMAKE_ABSOLUTE_DESTINATION_FILES}")
  endif()
  file(INSTALL DESTINATION "/integration_mpi" TYPE EXECUTABLE FILES "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/domain_gpu")
  if(EXISTS "$ENV{DESTDIR}/integration_mpi/domain_gpu" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}/integration_mpi/domain_gpu")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}/integration_mpi/domain_gpu"
         OLD_RPATH "/usr/local/lib:/usr/local/cuda-12.3/lib64:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}/integration_mpi/domain_gpu")
    endif()
  endif()
endif()

