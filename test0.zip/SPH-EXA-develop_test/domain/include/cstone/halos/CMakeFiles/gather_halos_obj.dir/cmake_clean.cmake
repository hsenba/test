file(REMOVE_RECURSE
  "CMakeFiles/gather_halos_obj.dir/gather_halos_gpu.cu.o"
  "CMakeFiles/gather_halos_obj.dir/gather_halos_gpu.cu.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/gather_halos_obj.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
