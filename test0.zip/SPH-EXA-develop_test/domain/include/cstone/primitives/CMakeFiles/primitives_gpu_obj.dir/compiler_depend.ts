# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for primitives_gpu_obj.
