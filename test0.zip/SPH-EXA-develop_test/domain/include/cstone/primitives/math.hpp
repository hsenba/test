/*! @file
 * @brief  Basic math
 *
 * @author Sebastian Keller <sebastian.f.keller@gmail.com>
 */

#pragma once

#include <cstdint>

#include "cstone/cuda/annotation.hpp"
#include "cstone/tree/definitions.h"

namespace cstone
{

//! @brief ceil(dividend/divisor) for unsigned integers
HOST_DEVICE_FUN constexpr size_t iceil(size_t dividend, unsigned divisor)
{
    return (dividend + divisor - 1lu) / divisor;
}

//! @brief round up @p n to multiple of @p m
HOST_DEVICE_FUN constexpr size_t round_up(size_t n, unsigned m) { return ((n + m - 1) / m) * m; }

template<class T, size_t N>
HOST_DEVICE_FUN void fitQuadratic(const util::array<cstone::Vec2<T>, N> &points, int n_, T &a, T &b, T &c) {
    T sum_x = T(0), sum_x2 = T(0), sum_x3 = T(0), sum_x4 = T(0);
    T sum_y = T(0), sum_xy = T(0), sum_x2y = T(0);
    for (size_t i=0; i<n_; ++i) {
        T x = points[i][0];
        T y = points[i][1];

        sum_x += x;
        sum_x2 += x*x;
        sum_x3 += x*x*x;
        sum_x4 += x*x*x*x;
        sum_y += y;
        sum_xy += x*y;
        sum_x2y += x*x*y;
    }
    T n = T(n_);
    T denom = n * (sum_x2 * sum_x4 - sum_x3 * sum_x3) - sum_x * (sum_x * sum_x4 - sum_x2 * sum_x3) + sum_x2 * (sum_x * sum_x3 - sum_x2 * sum_x2);

    if (denom == T(0)) {
        a = T(0); b = T(0); c = T(0);
        return;
    }

    a = (sum_x2y*(n*sum_x2-sum_x*sum_x) - sum_xy*(sum_x3*n-sum_x*sum_x2) + sum_y*(sum_x*sum_x3-sum_x2*sum_x2)) / denom;
    b = (-sum_x2y*(n*sum_x3-sum_x*sum_x2) + sum_xy*(n*sum_x4-sum_x2*sum_x2) - sum_y*(sum_x*sum_x4-sum_x2*sum_x3)) / denom;
    c = (sum_x2y*(sum_x*sum_x3-sum_x2*sum_x2) - sum_xy*(sum_x*sum_x4-sum_x2*sum_x3) + sum_y*(sum_x2*sum_x4-sum_x3*sum_x3)) / denom;
 
}

template<class T, size_t N>
HOST_DEVICE_FUN void heapify(util::array<cstone::Vec2<T>, N> &arr, int n, int i) {
    int largest = i;
    int left = 2*i+1;
    int right = 2*i+2;
    if (left < n && arr[left][0] > arr[largest][0]) {
        largest = left;
    }
    if (right < n && arr[right][0] > arr[largest][0]) {
        largest = right;
    }
    if (largest != i) {
        util::swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}


template<class T, size_t N>
HOST_DEVICE_FUN void heapSort(util::array<cstone::Vec2<T>, N> &arr, int n) {
    for (int i=n/2-1; i>=0; i--) {
        heapify(arr, n, i);
    }
    for (int i=n-1; i>0; i--) {
        util::swap(arr[0], arr[i]);
        heapify(arr, i, 0);
    }
}

} // namespace cstone