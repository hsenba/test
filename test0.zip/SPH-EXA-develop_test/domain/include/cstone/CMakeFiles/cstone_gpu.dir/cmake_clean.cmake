file(REMOVE_RECURSE
  "libcstone_gpu.a"
  "libcstone_gpu.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/cstone_gpu.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
