file(REMOVE_RECURSE
  "CMakeFiles/octree_obj.dir/csarray_gpu.cu.o"
  "CMakeFiles/octree_obj.dir/csarray_gpu.cu.o.d"
  "CMakeFiles/octree_obj.dir/octree_gpu.cu.o"
  "CMakeFiles/octree_obj.dir/octree_gpu.cu.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/octree_obj.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
