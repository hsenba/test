file(REMOVE_RECURSE
  "CMakeFiles/hilbert_perf_gpu.dir/hilbert.cu.o"
  "CMakeFiles/hilbert_perf_gpu.dir/hilbert.cu.o.d"
  "hilbert_perf_gpu"
  "hilbert_perf_gpu.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/hilbert_perf_gpu.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
