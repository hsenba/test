file(REMOVE_RECURSE
  "CMakeFiles/assignment_gpu.dir/assignment_gpu.cpp.o"
  "CMakeFiles/assignment_gpu.dir/assignment_gpu.cpp.o.d"
  "CMakeFiles/assignment_gpu.dir/test_main.cpp.o"
  "CMakeFiles/assignment_gpu.dir/test_main.cpp.o.d"
  "assignment_gpu"
  "assignment_gpu.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/assignment_gpu.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
