# Empty dependencies file for gather_halos_obj.
# This may be replaced when dependencies are built.
