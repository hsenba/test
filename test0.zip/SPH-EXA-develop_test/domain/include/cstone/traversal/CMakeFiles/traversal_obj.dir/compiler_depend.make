# Empty compiler generated dependencies file for traversal_obj.
# This may be replaced when dependencies are built.
