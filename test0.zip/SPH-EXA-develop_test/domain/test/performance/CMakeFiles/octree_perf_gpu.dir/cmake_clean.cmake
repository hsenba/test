file(REMOVE_RECURSE
  "CMakeFiles/octree_perf_gpu.dir/octree.cu.o"
  "CMakeFiles/octree_perf_gpu.dir/octree.cu.o.d"
  "octree_perf_gpu"
  "octree_perf_gpu.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/octree_perf_gpu.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
