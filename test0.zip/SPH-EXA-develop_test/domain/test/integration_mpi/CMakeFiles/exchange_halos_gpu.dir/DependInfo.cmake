
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/exchange_halos_gpu.cpp" "domain/test/integration_mpi/CMakeFiles/exchange_halos_gpu.dir/exchange_halos_gpu.cpp.o" "gcc" "domain/test/integration_mpi/CMakeFiles/exchange_halos_gpu.dir/exchange_halos_gpu.cpp.o.d"
  "/home/mhirota/work/SPH-EXA-develop/domain/test/integration_mpi/test_main.cpp" "domain/test/integration_mpi/CMakeFiles/exchange_halos_gpu.dir/test_main.cpp.o" "gcc" "domain/test/integration_mpi/CMakeFiles/exchange_halos_gpu.dir/test_main.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/mhirota/work/SPH-EXA-develop/domain/include/cstone/CMakeFiles/cstone_gpu.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
