# CMake generated Testfile for 
# Source directory: /home/mhirota/work/SPH-EXA-develop/domain/include/cstone/halos
# Build directory: /home/mhirota/work/SPH-EXA-develop/domain/include/cstone/halos
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
