# CMake generated Testfile for 
# Source directory: /home/mhirota/work/SPH-EXA-develop/domain/test/coord_samples
# Build directory: /home/mhirota/work/SPH-EXA-develop/domain/test/coord_samples
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[CoordinateTests]=] "/home/mhirota/work/SPH-EXA-develop/domain/test/coord_samples/coordinate_test")
set_tests_properties([=[CoordinateTests]=] PROPERTIES  _BACKTRACE_TRIPLES "/home/mhirota/work/SPH-EXA-develop/domain/test/coord_samples/CMakeLists.txt;6;add_test;/home/mhirota/work/SPH-EXA-develop/domain/test/coord_samples/CMakeLists.txt;0;")
