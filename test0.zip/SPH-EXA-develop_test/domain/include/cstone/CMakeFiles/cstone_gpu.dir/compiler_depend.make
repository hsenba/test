# Empty compiler generated dependencies file for cstone_gpu.
# This may be replaced when dependencies are built.
