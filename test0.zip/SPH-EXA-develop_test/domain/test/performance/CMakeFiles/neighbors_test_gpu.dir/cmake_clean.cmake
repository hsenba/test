file(REMOVE_RECURSE
  "CMakeFiles/neighbors_test_gpu.dir/neighbor_driver.cu.o"
  "CMakeFiles/neighbors_test_gpu.dir/neighbor_driver.cu.o.d"
  "neighbors_test_gpu"
  "neighbors_test_gpu.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/neighbors_test_gpu.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
