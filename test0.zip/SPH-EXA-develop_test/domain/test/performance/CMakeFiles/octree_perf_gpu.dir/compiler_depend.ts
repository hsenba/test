# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for octree_perf_gpu.
