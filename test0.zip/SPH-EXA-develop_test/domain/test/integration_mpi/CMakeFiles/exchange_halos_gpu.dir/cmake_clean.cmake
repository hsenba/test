file(REMOVE_RECURSE
  "CMakeFiles/exchange_halos_gpu.dir/exchange_halos_gpu.cpp.o"
  "CMakeFiles/exchange_halos_gpu.dir/exchange_halos_gpu.cpp.o.d"
  "CMakeFiles/exchange_halos_gpu.dir/test_main.cpp.o"
  "CMakeFiles/exchange_halos_gpu.dir/test_main.cpp.o.d"
  "exchange_halos_gpu"
  "exchange_halos_gpu.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/exchange_halos_gpu.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
