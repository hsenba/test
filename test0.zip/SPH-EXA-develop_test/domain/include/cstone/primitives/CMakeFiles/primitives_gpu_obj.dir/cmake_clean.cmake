file(REMOVE_RECURSE
  "CMakeFiles/primitives_gpu_obj.dir/primitives_gpu.cu.o"
  "CMakeFiles/primitives_gpu_obj.dir/primitives_gpu.cu.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/primitives_gpu_obj.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
