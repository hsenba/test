# Empty compiler generated dependencies file for reallocate_obj.
# This may be replaced when dependencies are built.
