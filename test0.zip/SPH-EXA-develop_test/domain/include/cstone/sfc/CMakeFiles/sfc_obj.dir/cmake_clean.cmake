file(REMOVE_RECURSE
  "CMakeFiles/sfc_obj.dir/sfc_gpu.cu.o"
  "CMakeFiles/sfc_obj.dir/sfc_gpu.cu.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/sfc_obj.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
