# Empty compiler generated dependencies file for sfc_obj.
# This may be replaced when dependencies are built.
