# Empty dependencies file for primitives_gpu_obj.
# This may be replaced when dependencies are built.
