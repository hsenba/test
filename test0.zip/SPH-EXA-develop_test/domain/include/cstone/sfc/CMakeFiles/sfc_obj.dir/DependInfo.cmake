
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/mhirota/work/SPH-EXA-develop/domain/include/cstone/sfc/sfc_gpu.cu" "domain/include/cstone/sfc/CMakeFiles/sfc_obj.dir/sfc_gpu.cu.o" "gcc" "domain/include/cstone/sfc/CMakeFiles/sfc_obj.dir/sfc_gpu.cu.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
