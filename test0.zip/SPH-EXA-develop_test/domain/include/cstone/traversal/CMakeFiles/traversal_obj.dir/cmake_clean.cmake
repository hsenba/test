file(REMOVE_RECURSE
  "CMakeFiles/traversal_obj.dir/collisions_gpu.cu.o"
  "CMakeFiles/traversal_obj.dir/collisions_gpu.cu.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/traversal_obj.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
